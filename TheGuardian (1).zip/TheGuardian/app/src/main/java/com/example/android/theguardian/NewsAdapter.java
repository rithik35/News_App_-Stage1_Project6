package com.example.android.theguardian;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class NewsAdapter extends ArrayAdapter<News> {

    public NewsAdapter(Activity context, List<News> news) {

        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, news);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        News currentNews = getItem(position);

        //find the TextView of the section name  in the list_item with id : section
        TextView section = listItemView.findViewById(R.id.section);
        section.setText(currentNews.getSection());

        //find the TextView of the date  in the list_item with id : date
        TextView date = listItemView.findViewById(R.id.date);
        date.setText(currentNews.getDate());

        //find the TextView of the section name  in the list_item with id : title
        TextView title = listItemView.findViewById(R.id.title);
        title.setText(currentNews.getTitle());

        //find the TextView of the trail text  in the list_item with id : trailText
        TextView trailText = listItemView.findViewById(R.id.trailText);
        trailText.setText(currentNews.getTrailText());

        //find the TextView of the author name in the list_item with id : author
        TextView author = listItemView.findViewById(R.id.author);
        author.setText(currentNews.getAuthor());

        return listItemView;
    }
}
