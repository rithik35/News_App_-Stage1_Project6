package com.example.android.theguardian;

public class News {

    /***** the name of the section ******/
    private String mSection;

    /*** Date ***/
    private String mDate;

    private String mTitle ;

    private String mUrl;

    private String mTrailText;

    private String mAuthor;


    public News(String mSection,String mDate, String mTitle, String mUrl, String mTrailText, String mAuthor) {
        this.mSection = mSection;
        this.mDate = mDate;
        this.mTitle = mTitle;
        this.mUrl = mUrl;
        this.mTrailText = mTrailText;
        this.mAuthor = mAuthor;
    }

    /** Getter methods  ****/
    public String getSection() {
        return mSection;
    }

    public String getDate() {
        return mDate;
    }

    public String getTitle() {
        return mTitle;
    }

    public String getUrl() {
        return mUrl;
    }

    public String getTrailText() { return mTrailText; }

    public String getAuthor() {
        return mAuthor;
    }

}
